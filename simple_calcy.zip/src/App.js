import React, { Component } from 'react'
import ComponentFirst from './Component/ComponentFirst'

export default class App extends Component {
  render() {
    return (
      <div>
        <ComponentFirst/>
      </div>
    )
  }
}

